document.getElementById("mobileButton").onclick = function () {
  document.getElementById("tfNav").classList.add("active");
};
document.getElementById("closeNav").onclick = function () {
  document.getElementById("tfNav").classList.remove("active");
};
