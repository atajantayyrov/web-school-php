<section class="tf-about-us">
    <div class="tf-container">
        <div class="tf-about-us__wrapper">
        <div class="tf-about-us__img">
            <img src="img/about-us/manager.png" alt="adam"/>
            <span></span>
        </div>
        <div class="tf-about-us__text">
            <h2>Lorem ipsum dolor</h2> 
            <p>sit amet consectetur adipisicing elit. Officiis corrupti eveniet corporis ipsam alias quidem enim eligendi omnis natus, facere ad. Suscipit recusandae eum autem nostrum dolor tenetur dicta dignissimos?
            </p>
            <div class="tf-about-us__lists">
            <ul class="tf-about-us__list">
                <li class="tf-about-us__list-item">sit amet consectetur adipisicing </li>
                <li class="tf-about-us__list-item">sit amet consectetur adipisicing</li>
                <li class="tf-about-us__list-item">sit amet consectetur adipisicing</li>
            </ul>
            <ul class="tf-about-us__list">
                <li class="tf-about-us__list-item">sit amet consectetur adipisicing </li>
                <li class="tf-about-us__list-item">sit amet consectetur adipisicing</li>
                <li class="tf-about-us__list-item">sit amet consectetur adipisicing</li>
            </ul>
            </div>
        </div>
        </div>
    </div>
</section>