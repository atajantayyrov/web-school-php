<footer>
<div class="tf-footer">
    <div class="tf-container">
        <div class="tf-footer__wrapper">
            <div class="tf-footer__logo">
                <div class="tf-footer__logo-circle">
                <span>T</span>
                <span>F</span>
                </div>  
            </div>
            <div class="tf-footer__text">
                <h2><span>Turkmen</span><span>Freelancer</span></h2>
                <p>Etiam feugiat pellentesque odio, non placerat felis sagittis vitae. Praesent tristique sagittis urna et vestibulum. Suspendisse nulla libero, posuere non tristique quis, pretium sed justo.</p>
            </div>
            <div class="tf-footer__icon">
                <div class="tf-footer__icon-wrapper">
                <a href="#!"><i class="fa fa-whatsapp" aria-hidden="true"></i>
                </a>
                <a href="#!"><i class="fa fa-youtube-play" aria-hidden="true"></i>
                </a>
                <a href="#!"><i class="fa fa-instagram" aria-hidden="true"></i>
                </a>
                 <a href="#!"><i class="fa fa-facebook" aria-hidden="true"></i>
                </a>
                <a href="#!"><i class="fa fa-twitter" aria-hidden="true"></i>
                </a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="tf-copyrights">
    <p>Copyright © 2020</p>
</div>
</footer>