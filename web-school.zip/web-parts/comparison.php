<section class="tf-comparison">
    <div class="tf-container">
        <div class="tf-comparison__text">
            <h2>Gymmatmy?</h2>
            <p>Etiam feugiat pellentesque odio, non placerat felis sagittis vitae. Praesent tristique sagittis urna et<br> vestibulum. Suspendisse nulla libero, posuere non tristique quis, pretium sed justo.</p>
        </div>
        <div class="tf-comparison__size">
            <table class="tf-comparison__table">
                <tr>
                    <th></th>
                    <th class="tf-table__logo"><span>T</span><span>F</span></th>
                    <th>Başga Kompaniýa</th>
                    <th>Başga Kompaniýa</th>
                </tr>
                <tr>
                    <td>Websaýt görnüşi</td>
                    <td><span>Griffin</span><span>Täze dizaýn, arassa kod</span></td>
                    <td><span>Griffin</span><span>Mugt ýüklenen taýyn şablon</span</td>
                    <td><span>Griffin</span><span>Hili pes mugt şablon</span</td>
                </tr>
                <tr>
                    <td>Harjanan Wagt</td>
                    <td><span>~ 2 hepde</span><span>Dizaýn, kod</span</td>
                    <td><span>~ min. 4 hepde</span><span>Başga proýektlerden wagt bolanok</span</td>
                    <td><span>~ min. 6 hepde</span><span>Näbelli sebäpler wagty uzadýar</span</td>
                </tr>
                <tr>
                    <td>Hyzmat Hili</td>
                    <td><span>Ýokary</span><span>Hemme etapdan müşderi habarly</span</td>
                    <td><span>Pes</span><span>Müşderä diňe netije görkezilýär</span</td>
                    <td><span>Pes</span><span>Haçan nähili netije boljagy näbelli</span</td>
                </tr>
                <tr>
                    <td>Garantiýa</td>
                    <td><span>1 aý</span><span>Çykan näsazlyklar mugt</span</td>
                    <td><span>1 hepde</span><span>Çykan näsazlyklar mugt</span</td>
                    <td><span>0</span><span>Çykan näsazlyklar tölegli</span</td>
                </tr>
                </table>
            </div>
        <div class="tf-comparison__text">
            <p>Etiam feugiat pellentesque odio, non placerat felis sagittis vitae. Praesent tristique sagittis urna et<br> vestibulum. Suspendisse nulla libero, posuere non tristique quis, pretium sed justo.</p>
        </div>
    </div>
</section>