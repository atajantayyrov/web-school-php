<section class="tf-our-team">
<div class="tf-our-team__bg">
    <div class="tf-container">
        <div class="tf-our-team__wrapper">
        <div class="tf-our-team__text">
                        <h2>BIziň kommandamyz</h2>
                        <p> Etiam feugiat pellentesque odio, non placerat felis sagittis vitae. Praesent tristique sagittis urna et vestibulum. Suspendisse nulla libero, posuere non tristique quis, pretium sed justo.</p>
                    </div>
            <div class="tf-our-team__item">
                <div class="tf-our-team__main">
                <div class="tf-our-team__img">
                    <img src="img/staff.png" alt="img1" />   
                </div>
                    <div class="tf-our-team__name">
                        <h2>Atajan</h2>
                        <p>Web Developer</p>
                        </div>
                        <div class="tf-our-team__icon">
                        <a href="#!"><i class="fa fa-github" aria-hidden="true"></i>
                        </a>
                        <a href="#!"><i class="fa fa-bitbucket" aria-hidden="true"></i>
                        </a>
                        <a href="#!"><i class="fa fa-globe" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="tf-our-team__item">
                <div class="tf-our-team__main">
                <div class="tf-our-team__img">
                    <img src="img/staff.png" alt="img1" />   
                </div>
                    <div class="tf-our-team__name">
                        <h2>Atajan</h2>
                        <p>Web Developer</p>
                        </div>
                        <div class="tf-our-team__icon">
                        <a href="#!"><i class="fa fa-github" aria-hidden="true"></i>
                        </a>
                        <a href="#!"><i class="fa fa-bitbucket" aria-hidden="true"></i>
                        </a>
                        <a href="#!"><i class="fa fa-globe" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="tf-our-team__item">
                <div class="tf-our-team__main">
                <div class="tf-our-team__img">
                    <img src="img/staff.png" alt="img1" />   
                </div>
                    <div class="tf-our-team__name">
                        <h2>Atajan</h2>
                        <p>Web Developer</p>
                        </div>
                        <div class="tf-our-team__icon">
                        <a href="#!"><i class="fa fa-github" aria-hidden="true"></i>
                        </a>
                        <a href="#!"><i class="fa fa-bitbucket" aria-hidden="true"></i>
                        </a>
                        <a href="#!"><i class="fa fa-globe" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="tf-our-team__item">
                <div class="tf-our-team__main">
                <div class="tf-our-team__img">
                    <img src="img/staff.png" alt="img1" />   
                </div>
                    <div class="tf-our-team__name">
                        <h2>Atajan</h2>
                        <p>Web Developer</p>
                        </div>
                        <div class="tf-our-team__icon">
                        <a href="#!"><i class="fa fa-github" aria-hidden="true"></i>
                        </a>
                        <a href="#!"><i class="fa fa-bitbucket" aria-hidden="true"></i>
                        </a>
                        <a href="#!"><i class="fa fa-globe" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>