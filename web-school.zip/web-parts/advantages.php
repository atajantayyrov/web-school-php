<section class="tf-advantages">
        <div class="tf-container"> 
          <div class="tf-advantages__wrapper">
            <div class="tf-advantages__item">
              <div class="tf-advantages__icon">
                <i class="fa fa-snowflake-o" aria-hidden="true"></i>

              </div>
              <div class="tf-advantages__title">
                <h3>Lorem ipsum, dolor sit </h3>
              </div>
              <div class="tf-advantages__text">
                <p>amet consectetur adipisicing elit. Sit laboriosam aspernatur vel aliquam accusantium necessitatibus fuga ullam quos dicta quia laborum mollitia eum, incidunt porro harum consequatur? Iusto, ipsa neque.</p>
              </div>
            </div>
            <div class="tf-advantages__item">
              <div class="tf-advantages__icon">
                <i class="fa fa-ravelry" aria-hidden="true"></i>
              </div>
              <div class="tf-advantages__title">
                <h3>Lorem ipsum, dolor sit </h3>
              </div>
              <div class="tf-advantages__text">
                <p>amet consectetur adipisicing elit. Sit laboriosam aspernatur vel aliquam accusantium necessitatibus fuga ullam quos dicta quia laborum mollitia eum, incidunt porro harum consequatur? Iusto, ipsa neque.</p>
              </div>
            </div>
            <div class="tf-advantages__item">
              <div class="tf-advantages__icon">
                <i class="fa fa-grav" aria-hidden="true"></i>
              </div>
              <div class="tf-advantages__title">
                <h3>Lorem ipsum, dolor sit </h3>
              </div>
              <div class="tf-advantages__text">
                <p>amet consectetur adipisicing elit. Sit laboriosam aspernatur vel aliquam accusantium necessitatibus fuga ullam quos dicta quia laborum mollitia eum, incidunt porro harum consequatur? Iusto, ipsa neque.</p>
              </div>
            </div>
            <div class="tf-advantages__item">
              <div class="tf-advantages__icon">
                <i class="fa fa-anchor" aria-hidden="true"></i>
              </div>
              <div class="tf-advantages__title">
                <h3>Lorem ipsum, dolor sit </h3>
              </div>
              <div class="tf-advantages__text">
                <p>amet consectetur adipisicing elit. Sit laboriosam aspernatur vel aliquam accusantium necessitatibus fuga ullam quos dicta quia laborum mollitia eum, incidunt porro harum consequatur? Iusto, ipsa neque.</p>
              </div>
            </div>
          </div>
        </div>
      </section>