<section class="tf-video-about-us">
        <div class="tf-container">
          <div class="tf-video-about-us__wrapper">
            <div class="tf-video-about-us__video">
              <video controls="" loop="" muted="" poster="img/website@2x.png">
                <source src="video/background-video.mp4" type="video/mp4">
                  <p>video sizde ishlanok</p>
              </video>
            </div>
            <div class="tf-video-about-us__content">

              <div class="tf-video-about-us__text">
                <h2>biz hakda video</h2>
                <p>Etiam feugiat pellentesque odio, non placerat felis sagittis vitae. Praesent tristique sagittis urna et vestibulum. Suspendisse nulla libero, posuere non tristique quis, pretium sed justo. Maecenas ornare venenatis velit, sed ullamcorper mi porttitor sed. Donec semper finibus dolor, nec fermentum enim bibendum sed. Aliquam dapibus velit augue, nec mollis sapien ullamcorper aliquam. Mauris eu erat in metus volutpat condimentum. Vestibulum vitae leo fermentum, rhoncus mi at, hendrerit lorem.</p>
              </div>
              <span class="tf-video-about-us__circle"></span>
            </div>
          </div>
        </div>
      </section>