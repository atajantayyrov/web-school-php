<section class="tf-slogan">
        <div class="tf-slogan__wrapper">
          <div class="tf-slogan__video">
            <video autoplay="" loop="" muted="" poster="img/video-bg.png">
              <source src="video/background-video.mp4" type="video/mp4">
                <p>video sizde ishlanok</p>
            </video>
          </div>
          <div class="tf-slogan__content">
            <div class="tf-slogan__text">
              <h3>Dünýä standartlarynda</h3>
              <h2>Modern dizaýn</h2>
              <p>Lead paragraph. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Duis mollis, est non commodo luctus.</p>
            </div>
          </div>
        </div>
      </section>