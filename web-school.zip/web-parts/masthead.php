<section class="tf-masthead">
        <div class="tf-container tf-masthead__wrapper">
          <div class="tf-masthead__text">
            <h2>Gysga wagta, amatly baha</h2>
            <h1>ussat çozgütler</h1>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius
              earum ea reprehenderit adipisci reiciendis perspiciatis cumque
              labore, eos iusto laboriosam, quos distinctio quia impedit!
              Asperiores minus molestiae numquam quas earum!
            </p>
            <a href="#!">habarlaşyň<i class="fa fa-phone"></i></a>
          </div>
          <div class="tf-masthead__img">
            <img src="img/main-image-3.png" alt="img1" />
            <span></span>
          </div>
        </div>
      </section>