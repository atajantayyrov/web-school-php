<section class="tf-contact-us">
<div class="tf-contact-us__bg">
    <div class="tf-container">
        <div class="tf-contact-us__row">
            <div class="tf-contact-us__col">
                <h2>siziň üstünligiňiz<span>biziň şatlygymyz</span></h2>
            </div>
            <div class="tf-contact-us__col">
                <div class="tf-contact-us__form">
                    <h3>Biz bilen habarlaşyŇ</h3>
                    <form class="tf-form" id="contactUs" action="">
                        <input class="tf-form__input" id="firstName" name="first-name" type="text" placeholder="Doly Adyňyz">
                        <input class="tf-form__input" id="telephone" name="telephone-number" type="number" placeholder="Telefon Belgiňiz">
                        <div class="tf-form__select-with-button">
                            <select class="tf-form__select" name="services" id="services">
                                <option value="0">Gyzyklandyrýan hyzmat</option>
                                <option value="website">Web site</option>
                                <option value="dizayn">Dizayn</option>
                            </select>
                            <i class="fa fa-chevron-circle-down" aria-hidden="true"></i>
                        </div>
                        <input type="submit" class="tf-form__submit" id="formSubmit" value="maňa jaň ediň">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
